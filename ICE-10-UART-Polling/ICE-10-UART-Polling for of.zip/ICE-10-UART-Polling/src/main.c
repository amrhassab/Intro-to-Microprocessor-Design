//*****************************************************************************
// main.c
// Author: jkrachey@wisc.edu
//*****************************************************************************
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdbool.h>

#include "TM4C123.h"
#include "gpioPort.h"
#include "uart.h"


//*****************************************************************************
// Configure PA0 and PA1 to be UART pins
//*****************************************************************************
void uart0_config_gpio(void)
{
  
	gpio_enable_port(UART0_BASE);
	gpio_config_digital_enable(UART0_BASE, GPIO_PCTL_PA0_U0RX|GPIO_PCTL_PA1_U0TX );
	gpio_config_alternate_function(UART0_BASE, GPIO_PCTL_PA0_M|GPIO_PCTL_PA1_M);
	gpio_config_port_control(UART0_BASE, GPIO_PCTL_PA0_M|GPIO_PCTL_PA1_M);

}



//*****************************************************************************
//*****************************************************************************
int 
main(void)
{
  char greeting[] = "\n\r\n\rEnter an 4-digit number: ";
  char response[] = "\n\rYou entered:";
  char exit_msg[] = "\n\r\n\rGoodbye.";
  char rx_char;
  char rx_string[5] = {0,0,0,0,0};
  uint8_t rx_count = 0;  
  
  // Configure the GPIO pins
	uart0_config_gpio();
  
  // Configure the UART
  uart_init_115K(UART0_BASE);
  // Print greeting string above
	
  uartTxPoll(UART0_BASE, greeting);

  // Get User Input

  // Print the response string
  
  // Print rx_string
  
  // Print exit_msg

  
  while(1)
  {
     // Infinite Loop
  }
}
