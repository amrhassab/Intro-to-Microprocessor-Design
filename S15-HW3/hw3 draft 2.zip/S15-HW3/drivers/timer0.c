#include "timer0.h"

TIMER0_Type *gp_timer;

//*****************************************************************************
// Configure Timer 0 to be two 16-bit, periodic, count down timers.
// Do not set the values for TAILR or TBILR and DO NOT enable the timer.
//*****************************************************************************
void configure_timer0(void){
	// Set the timer to be in 16-bit mode (CFG)
	gp_timer->CFG = TIMER_CFG_16_BIT;
	//Set the Timer A Mode Register to be in periodic mode and count down (TAMR)
	gp_timer->TAMR = TIMER_TAMR_TAMR_PERIOD; 
}

//*****************************************************************************
// Turns on Timer0A and Turns Off Timer0B.  The TAILR is set to load_value
//*****************************************************************************
void start_timer0A(uint16_t load_value){
	// Disable the B timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TBEN);
	// Enable the A timer (CTL)
	gp_timer->CTL |= TIMER_CTL_TAEN;
	// Set the number of clock cycles in the Timer A Interval Load Register (TAILR)
	gp_timer->TAILR = load_value;
	
}

//*****************************************************************************
// Turns off Timer0A.  This function does not alter the load value.
//*****************************************************************************
void stop_timer0A(void){
	// Disable the A timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TAEN);
}

//*****************************************************************************
// Turns on Timer0B and Turns Off Timer0A.  The TBILR is set to load_value
//*****************************************************************************
void start_timer0B(uint16_t load_value){
	// Disable the A timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TAEN);
	// Enable the B timer (CTL)
	gp_timer->CTL |= TIMER_CTL_TBEN;
	// Set the number of clock cycles in the Timer B Interval Load Register (TAILR)
	gp_timer->TBILR = load_value;
	
}

//*****************************************************************************
// Turns off Timer0B.  This function does not alter the load value.
//*****************************************************************************
void stop_timer0B(void){
	// Disable both the B timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TBEN);	
}
