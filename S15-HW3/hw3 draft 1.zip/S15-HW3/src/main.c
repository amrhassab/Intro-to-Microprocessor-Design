//*****************************************************************************
// main.c
// Author: jkrachey@wisc.edu
//*****************************************************************************
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "TM4C123.h"
#include "gpioPort.h"
#include "adc.h"
#include "timer0.h"
#include "boardUtil.h"


extern void serialDebugInit(void);
char  teamNumber[] = "00";
char person1[] = "Your Name";
char person2[] = "Your Partner's Name" ;

//*****************************************************************************
//*****************************************************************************
int 
main(void)
{

  /*  debug stuff */
	
	uint16_t x_data, y_data, pot_data;
	uint32_t i;
	
	/*debug stuff */
	
	
	
  serialDebugInit();
  
  printf("\n\r");
  printf("***************************************\n\r");
  printf("ECE353 Spring 2015  - HW3 \n\r");
  printf("\tTeam %s\n\r", teamNumber);
  printf("\t%s\n\r", person1);
  printf("\t%s\n\r", person2);
  printf("****************************************\n\r");
  
	

	
	
	
  /***** peripheral requirements *****/
	  
  /* a. Digital GPIO PINS */
		
	// configure the UP direction button as digitaol input
  gpio_enable_port(GPIOF_BASE);
	gpio_config_enable_input(GPIOF_BASE, PUSH_BUTTON_UP_PIN);
	gpio_config_digital_enable(GPIOF_BASE, PUSH_BUTTON_UP_PIN);
  gpio_config_enable_pullup(GPIOF_BASE, PUSH_BUTTON_UP_PIN);
	
	// configure DAC5-0 as digital outputs
	gpio_enable_port(GPIOB_BASE);
	gpio_config_enable_output(GPIOB_BASE, DAC_GPIO_0|DAC_GPIO_1|DAC_GPIO_2|DAC_GPIO_3
	|DAC_GPIO_4|DAC_GPIO_5);
	
	
	/* b. analog GPIO pins */
		
	// configure pins conected to ps2 stick and pot. to Analog in
  gpio_enable_port(GPIOE_BASE);
	gpio_config_enable_input(GPIOE_BASE, ADC_GPIO_X_PIN | ADC_GPIO_Y_PIN 
	| ADC_GPIO_POT_PIN);
	gpio_config_analog_enable(GPIOE_BASE,ADC_GPIO_X_PIN | ADC_GPIO_Y_PIN 
	| ADC_GPIO_POT_PIN );
	gpio_config_alternate_function(GPIOE_BASE, ADC_GPIO_X_PIN | ADC_GPIO_Y_PIN 
	| ADC_GPIO_POT_PIN);
	
	
	/* c. ADC0 */
	configure_adc0();
	
	
	
	
		
		
	
  while(1)
  {
		get_adc_values( ADC0_BASE, &x_data, &y_data, &pot_data);
		printf("X Dir value : %03d        Y Dir value : %03d      pot value : %d\r",x_data, y_data, pot_data);
    for(i=0;i<1000000; i++){}
		
  }
}
