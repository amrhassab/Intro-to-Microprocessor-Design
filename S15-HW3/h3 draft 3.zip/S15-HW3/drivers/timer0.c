#include "timer0.h"

TIMER0_Type *gp_timer;

//*****************************************************************************
// Configure Timer 0 to be two 16-bit, periodic, count down timers.
// Do not set the values for TAILR or TBILR and DO NOT enable the timer.
//*****************************************************************************
void configure_timer0(void){
	
	// turn on clock for the timer0
	SYSCTL->RCGCTIMER |= SYSCTL_RCGCTIMER_R0;
	
	//wait for the timer to turn on 
	while((SYSCTL->PRTIMER & SYSCTL_PRTIMER_R0) == 0) {};
	
	// turn off the timer before configuration
	gp_timer->CTL &= ~(TIMER_CTL_TBEN | TIMER_CTL_TAEN);
	
	// Set the timer to be in 16-bit mode (CFG)
	gp_timer->CFG = TIMER_CFG_16_BIT;
	
	//Set the Timer A Mode Register to be in periodic mode and count down (TAMR)
	gp_timer->TAMR = TIMER_TAMR_TAMR_PERIOD; 
	gp_timer->TBMR = TIMER_TBMR_TBMR_PERIOD; 
		
	//gp_timer->IMR = TIMER_IMR_TBTOIM | TIMER_IMR_TATOIM; 
		
}

//*****************************************************************************
// Turns on Timer0A and Turns Off Timer0B.  The TAILR is set to load_value
//*****************************************************************************
void start_timer0A(uint16_t load_value){
	
	// Set the number of clock cycles in the Timer A Interval Load Register (TAILR)
	gp_timer->TAILR = load_value;
	
	// clear any status bits indicating that the time has expired 
	gp_timer->ICR |= TIMER_ICR_TATOCINT;
		
	// Disable the B timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TBEN);
	
	// Enable the A timer (CTL)
	gp_timer->CTL |= TIMER_CTL_TAEN;
	
	while((gp_timer->RIS & TIMER_RIS_TATORIS) == 0) {}
}

//*****************************************************************************
// Turns off Timer0A.  This function does not alter the load value.
//*****************************************************************************
void stop_timer0A(void){
	// Disable the A timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TAEN);
}

//*****************************************************************************
// Turns on Timer0B and Turns Off Timer0A.  The TBILR is set to load_value
//*****************************************************************************
void start_timer0B(uint16_t load_value){
	// Set the number of clock cycles in the Timer B Interval Load Register (TAILR)
	gp_timer->TBILR = load_value;
	
	// clear any status bits indicating that the time has expired 
	gp_timer->ICR |= TIMER_ICR_TBTOCINT;
	
	// Disable the A timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TAEN);
	
	// Enable the B timer (CTL)
	gp_timer->CTL |= TIMER_CTL_TBEN;
	
	while((gp_timer->RIS & TIMER_RIS_TBTORIS) == 0) {}
	
}

//*****************************************************************************
// Turns off Timer0B.  This function does not alter the load value.
//*****************************************************************************
void stop_timer0B(void){
	// Disable both the B timer (CTL)
	gp_timer->CTL &= ~(TIMER_CTL_TBEN);	
}
